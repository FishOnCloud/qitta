import logging
import os
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from openai import APIStatusError, APITimeoutError, OpenAI
from oci_openai import OciResourcePrincipalAuth
from pydantic import BaseModel, Field

app = FastAPI(title="OCI Generative AI web demo")
log = logging.getLogger("uvicorn.error")


class Message(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


@app.get("/")
@app.get("/ui")
def home():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/ready")
def ready():
    if os.getenv("GENAI_REGION") != "us-chicago-1" or not all(os.getenv(key) for key in ("GENAI_PROJECT_OCID", "GENAI_MODEL_ID")):
        raise HTTPException(503, "Missing application configuration")
    return {"status": "ready"}


@app.post("/api/chat")
def chat(payload: Message):
    ready()
    try:
        with OpenAI(
            api_key="not-used",
            base_url=f"https://inference.generativeai.{os.environ['GENAI_REGION']}.oci.oraclecloud.com/openai/v1",
            project=os.environ["GENAI_PROJECT_OCID"],
            http_client=httpx.Client(auth=OciResourcePrincipalAuth(), timeout=90),
            timeout=90,
            max_retries=0,
        ) as client:
            result = client.responses.create(
                model=os.environ["GENAI_MODEL_ID"],
                instructions="日本語で簡潔に回答してください。",
                input=payload.message,
            )
        if not result.output_text:
            raise HTTPException(502, "Model returned no text")
        return {"answer": result.output_text, "response_id": result.id}
    except APIStatusError as exc:
        request_id = exc.response.headers.get("opc-request-id") or exc.request_id or ""
        log.error("responses_error status=%s request_id=%s", exc.status_code, request_id)
        raise HTTPException(502, {"stage": "responses", "upstream_status": exc.status_code, "opc_request_id": request_id}) from exc
    except APITimeoutError as exc:
        raise HTTPException(504, {"stage": "responses", "error": "timeout"}) from exc
    except HTTPException:
        raise
    except Exception as exc:
        log.error("responses_error type=%s", type(exc).__name__)
        raise HTTPException(502, {"stage": "responses", "error_type": type(exc).__name__}) from exc
