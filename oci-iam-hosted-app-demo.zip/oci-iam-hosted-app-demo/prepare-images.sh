#!/usr/bin/env bash
set -euo pipefail

push=false
case "${1:-}" in
  '') ;;
  --push) push=true ;;
  *) echo 'Usage: bash prepare-images.sh [--push]' >&2; exit 2 ;;
esac
: "${OcirNamespace:?Set OcirNamespace}"
: "${OcirLogin:?Set OcirLogin}"
: "${GenaiProjectOcid:?Set GenaiProjectOcid}"
: "${GenaiModelId:?Set GenaiModelId}"
ImageTag=${ImageTag:-verify-v1}
LocalPort=${LocalPort:-8080}
case "$OcirLogin" in "$OcirNamespace"/*) ;; *) echo 'OcirLogin must start with Namespace/' >&2; exit 2 ;; esac
case "$GenaiProjectOcid" in ocid1.generativeaiproject.*) ;; *) echo 'Set the Generative AI Project OCID' >&2; exit 2 ;; esac
if [[ "$OcirNamespace $OcirLogin $GenaiProjectOcid $GenaiModelId $ImageTag" == *'<'* || "$OcirNamespace $OcirLogin $GenaiProjectOcid $GenaiModelId $ImageTag" == *'>'* ]]; then
  echo 'Replace all placeholders before running' >&2; exit 2
fi
[[ "$OcirNamespace" =~ ^[A-Za-z0-9_.-]+$ && "$ImageTag" =~ ^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$ ]] || { echo 'Invalid namespace or tag' >&2; exit 2; }
[[ "$LocalPort" =~ ^[0-9]+$ ]] && ((LocalPort >= 1024 && LocalPort <= 65535)) || { echo 'Invalid local port' >&2; exit 2; }
command -v docker >/dev/null
command -v curl >/dev/null
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p artifacts
run_dir=$(mktemp -d "$PWD/artifacts/images-XXXXXXXX")
container="iam-demo-check-$(basename "$run_dir")"
image="ord.ocir.io/$OcirNamespace/iam-demo-app:$ImageTag"
owned=false
status=FAIL
pushed=false
cleanup() {
  rc=$?
  trap - EXIT
  if $owned; then
    if ((rc != 0)); then docker logs "$container" >&2 || true; fi
    docker rm -f "$container" >/dev/null || true
  fi
  printf 'Status=%s\nImage=%s\nImagePushed=%s\n' "$status" "$image" "$pushed" > "$run_dir/summary.txt"
  echo "Results: $run_dir"
  exit "$rc"
}
trap cleanup EXIT
docker info >/dev/null
docker version > "$run_dir/docker-version.txt"
docker build --pull --platform linux/amd64 -t "$image" -f app/Dockerfile app
[[ $(docker image inspect "$image" --format '{{.Os}}/{{.Architecture}}') == linux/amd64 ]]
docker run --rm --entrypoint python "$image" -c "import httpx; from openai import OpenAI; from oci_openai import OciResourcePrincipalAuth; c=OpenAI(api_key='placeholder',project='placeholder',http_client=httpx.Client()); assert hasattr(c,'responses'); c.close(); print('App imports OK')"
docker image inspect "$image" > "$run_dir/image-inspect.json"
owned=true
docker run -d --name "$container" -p "127.0.0.1:$LocalPort:8080" \
  -e GENAI_REGION=us-chicago-1 -e "GENAI_PROJECT_OCID=$GenaiProjectOcid" -e "GENAI_MODEL_ID=$GenaiModelId" "$image"
healthy=false
for attempt in {1..30}; do
  if curl --disable --silent --show-error --fail --max-time 3 "http://127.0.0.1:$LocalPort/health" > "$run_dir/health.json" 2>/dev/null; then healthy=true; break; fi
  sleep 2
done
$healthy || { echo 'Local health check failed' >&2; exit 1; }
curl --disable --silent --show-error --fail --max-time 10 "http://127.0.0.1:$LocalPort/ready" > "$run_dir/ready.json"
curl --disable --silent --show-error --fail --max-time 10 "http://127.0.0.1:$LocalPort/ui" > "$run_dir/ui.html"
grep -q '<form' "$run_dir/ui.html"
if $push; then
  echo 'Enter the OCI Auth Token at the Docker Password prompt.'
  docker login ord.ocir.io --username "$OcirLogin"
  docker push "$image"
  pushed=true
fi
status=PASS
