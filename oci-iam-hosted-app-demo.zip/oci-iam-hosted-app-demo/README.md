# Hosted Application自身をWeb APIとして公開するサンプル

`app/` のFastAPIアプリをChicagoのHosted Applicationへ配置します。OCIRは `iam-demo-app` の1つです。Container Instanceは使いません。

- 入口：HostedのPublic endpoint＋認証なし（ご利用環境のコンソールにその選択肢があることが条件）。
- API：`GET /health`、`GET /ready`、`POST /api/chat`。
- 出口：HostedのResource PrincipalでChicagoのGenerative AI Responses APIを呼びます。
- 環境変数：`GENAI_REGION=us-chicago-1`、`GENAI_PROJECT_OCID`、`GENAI_MODEL_ID`。
- 配置：Docker版またはGit＋OCI DevOps版のどちらか一方を実施し、共通のHosted作成手順へ進みます。
- 検証：`bash test-deployment.sh "<画面のAPI endpoint、/actions/invokeまで>"`。署名・Bearer Tokenなしで推論を1回呼びます。
- 画面：`<API endpoint>/ui`（末尾スラッシュなし）。HTML応答がサービスを通過するかは実環境で別途確認します。JSON APIが必須の検証対象です。

公開ドキュメントでは認証なしの設定を確認できていません。コンソールの認証設定を撮影し、実測のHTTP応答で確認してください。

ローカルのhealth / ready確認は推論とResource Principal認証を実行しません。構文と模擬テストを確認済みで、実ビルド・Push・Hostedアクセス・OCI推論は未実施です。

旧 `hosted-agent/` と `web-proxy/` が作業フォルダーに残っている場合も使用しません。配布ZIPには含めません。

DockerとOCI CLIは準備済みの前提です。コマンドはBash形式で、Bash・curlが利用できるターミナルで実行します。Git版を使う場合はGitも必要です。jq・アプリ用Pythonを別途準備する必要はありません。

ApplicationとDeploymentはOCIコンソールで作成します。Dynamic Groupを作成できない場合のCompartment条件付きPolicyは手順の2.2を参照してください。HealthCheckはブラウザで、POSTはAPIテスト用アドオンまたは同梱スクリプトで確認できます。
