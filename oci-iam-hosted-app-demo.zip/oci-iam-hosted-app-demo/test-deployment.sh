#!/usr/bin/env bash
set -euo pipefail
base=${1:-${HostedBaseUrl:-}}
base=${base%/}
if [[ "$base" != https://*.generativeai.us-chicago-1.oci.oraclecloud.com/*/actions/invoke || "$base" == *'?'* || "$base" == *'#'* || "$base" == *'@'* || "$base" == *'<'* || "$base" == *'>'* ]]; then
  echo 'Usage: bash test-deployment.sh <Chicago HTTPS endpoint through /actions/invoke>' >&2; exit 2
fi
command -v curl >/dev/null
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p artifacts
run_dir=$(mktemp -d "$PWD/artifacts/deployment-XXXXXXXX")
status=FAIL
finish() {
  rc=$?
  trap - EXIT
  printf 'Status=%s\n' "$status" > "$run_dir/summary.txt"
  echo "Results: $run_dir"
  exit "$rc"
}
trap finish EXIT
for path in health ready; do
  code=$(curl --disable --silent --show-error --max-time 15 -H 'Accept: application/json' \
    -o "$run_dir/$path.json" -w '%{http_code}' "$base/$path")
  printf '%s\n' "$code" > "$run_dir/$path.http-status.txt"
  [[ "$code" == 200 ]] || { echo "$path returned HTTP $code; inference was not called" >&2; exit 1; }
done
# Exactly one inference request; no automatic retry and no Authorization header.
code=$(curl --disable --silent --show-error --max-time 150 \
  -H 'Accept: application/json' -H 'Content-Type: application/json' \
  --data '{"message":"OCIのResource Principalを日本語で一文で説明してください。"}' \
  -o "$run_dir/chat.json" -w '%{http_code}' "$base/api/chat")
printf '%s\n' "$code" > "$run_dir/chat.http-status.txt"
[[ "$code" == 200 ]] || { echo "Chat returned HTTP $code; inspect chat.json" >&2; exit 1; }
cat "$run_dir/chat.json"
printf '\n'
status=HTTP_PASS_CONTENT_CHECK_PENDING
echo 'Confirm answer and response_id in chat.json, then check /ui in a browser.'
